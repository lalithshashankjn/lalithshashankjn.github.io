$(document).ready(function () {
    $(".btn").click(function () {
        $(".btn").fadeOut("fast");;
    });
});




